<?php
	session_start(); 
	$pageTitle='Login Form';
	if(isset($_SESSION['user'])){
		
    header('Location: index.php');

  }

	include 'init.php';

	// Check User If User Come From HTTP Request
    if($_SERVER['REQUEST_METHOD']  == 'POST'){

    	if(isset($_POST['login'])){

        $user = $_POST['UserName'];
        $pass = $_POST['Password'];
        $hashedpass = sha1($pass);

       	// Check User If Exist In DB
        
        $stmt =$con->prepare("SELECT 
                                UserID,Username, Password
                                 From 
                                 users 
                                 WHERE 
                                 Username= ? 
                                 AND 
                                 Password = ? 
                                 
                            ");
        $stmt->execute(array($user,$hashedpass));

        $get = $stmt->fetch();

        $count = $stmt->rowCount();
        
        // If Count > 0 That Mean The Database Content This Record -- Username and Password 

        if ($count > 0){
       		$_SESSION['user'] = $user;//Register Session Name
       		$_SESSION['uid'] = $get['UserID']; //Get User ID in Seeion
       			header('Location: index.php');
       		exit();
        }
        
    }else{
    		$formError = array();

    		// My Main Variables
    		$user   = $_POST['UserName'];
    		$pass   = $_POST['Password'];
    		$pass22 = $_POST['Password2'];
    		$email  = $_POST['email'];

    		// Validate signup Username

    		if(isset($user)){

    			$filterdUser = filter_var($user, FILTER_SANITIZE_STRING);//Remove Tags

    			if(strlen($filterdUser) < 3){
    				$formError[] = '<div class="nice-message">Username Must Be Lager<strong> 3 </strong>Charachters</div>';
    			}
    		}
    		// Validate signup Password

    		if(isset($pass) && isset($pass22)){

    			$pass1 = sha1($pass) ;

    			$pass2 = sha1($pass22);

    			if( $pass1 !== $pass2 ){
    				$formError[] = '<div class="nice-message">Sorry Your Password is Not <strong>Identical</strong></div>';
    			}
    			if(empty($pass)){

    				$formError[] = '<div class="nice-message">Sorry You Cant Leave Password <strong>Empty</strong></div>';
    			
    			}
    			if(empty($pass22)){
    				
    				$formError[] = '<div class="nice-message">Sorry Password Confirmation Cant be <strong>Empty</strong></div>';
    			
    			}

    		}

    		// Validate signup Email
    		if(isset($email)){

    			$filterdEmail = filter_var($email , FILTER_SANITIZE_EMAIL);//Remove Tags

    			if(filter_var($filterdEmail, FILTER_VALIDATE_EMAIL) != true) {
    				$formError[] = '<div class="nice-message">Sorry Your Email is Not <strong>Vaild</strong></div>';
    			
    			}
    		}
    		// Check if no error procede to continue update
			if(empty($FormError)){
				// Check If User Exist in DataBase
				$check = CheckItem("Username","users",$user);

				if($check == 1){
					echo "<div class= 'container'>";
					$formError[] = '<div class="nice-message">Sorry Your Username is<strong> Exist</strong></div>';
					echo "</div>";

				}else{
					// Insert User Data
	                $stmt = $con->prepare('INSERT INTO 
	                                        users(Username,Password,Email,RegStutus,Date)
	                                        Values (:zuser,:zpass,:zemail,0,now())');
	                $stmt->execute(array(
	                    'zuser' => $user,
	                    'zpass' => sha1($pass),
	                    'zemail' => $email
	                ));
					// Echo Sucess Message
					$successmsg =$stmt->rowCount()." ". " Record Inserted";
				}
			}
    	}
	}



	?>

<div class="login-page">
	<div class="container">
			<h1 class="text-center">
				<span class="selected" data-class="login">Login</span> 
								| 
				<span data-class="sign">Sign Up</span> 
			</h1>
		<!--============================== Login Page ================================-->
		<form class="login" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST"> 
			<div class="input-container">
				<input 
					class="form-control "
					type="text" 
					placeholder="Enter Your User Name" 
					name="UserName" 
					autocomplete="off"
					required="required">
			</div>
			<div class="input-container">	
				<input 
					class="form-control" 
					type="password" 
					placeholder="Enter Your Password" 
					name="Password" 
					autocomplete="new-password"
					required="required" >
			</div>

				<input class="btn btn-primary form-control" name="login" type="Submit" value="Login" >
		</form>
		<!---==================== Sign Page ===========================-->
		<form class="sign" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
			<div class="input-container">
				<input 
					pattern=".{4,8}"
					title="Username Must Be 4 : 12 Chars" 
					class="form-control"
					type="text" 
					placeholder="Enter Your User Name" 
					name="UserName" 
					autocomplete="off" 
					required="required"
					>
			</div>
			<div class="input-container">
				<input 
					minlength="6" 
					class="form-control" 
					type="password" 
					placeholder="Enter Your Complex Password" 
					name="Password" 
					autocomplete="new-password"
					required="required"
					 >
			</div>
			<div class="input-container">
				<input 
					minlength="6" 
					class="form-control" 
					type="password" 
					placeholder="Enter Your Password Again" 
					name="Password2" 
					autocomplete="new-password"
					required="required"
					>
			</div>
			<div class="input-container">
				<input 
					class="form-control" 
					type="text" 
					placeholder="Enter Your Valid Email" 
					name="email" 
					autocomplete="off" 
					required="required"
					>

			</div>
				<input class="btn btn-success form-control" name="signup" type="Submit" value="Sign" >

		</form>
	</div>
</div>

	<!-- Validation and Show Errors-->
<div class="the-errors text-center container">
<?php
	if(! empty($formError)){

		foreach($formError as $Errors){
			echo $Errors ;
		}
	}
	if(isset($successmsg)){
		echo " <div class='success-message'>". $successmsg ."</div>";
	}

?>
	
</div>
<?php	include $tpl.'footer.php'; ?>