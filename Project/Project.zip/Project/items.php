<?php
	session_start(); 
	ob_start();
	$pageTitle='Show Items';

	include 'init.php';	

	// Condition To Get UserID Successfully
	$itemid = isset($_GET['itemid']) && is_numeric($_GET['itemid']) ? intval($_GET['itemid']) : 0;
	// Select All Data Depend To UserID
	$stmt =$con->prepare("SELECT 
							items.*,categories.Name AS Category_Name,users.Username  
						From 
							items 
						INNER JOIN 
							categories
						ON
						categories.ID = items.Cat_ID
						INNER JOIN
							users
						ON 
						users.UserID = items.Member_ID
						WHERE 
							item_ID= ?
							
						AND Approve = 1");
	// Execute Query
	$stmt->execute(array($itemid));

	$count = $stmt->rowCount(); 

	if($count > 0){
		// Print In Array
		$item = $stmt->fetch();

?>
	<!--Start My Header  Profile Page -->
	<h1 class="text-center"> <?php echo $item['Name']; ?> </h1>
	<div class="container">
		<div class="row">
			<div class="col-md-3">
				<img class='img-responsive img-thumbnail center-block' src='d.png' alt='Item Image'/>
			</div>
			<div class="col-md-9 item-info">
				<h2><?php echo $item['Name']; ?></h2>
				<p><?php echo $item['Description']; ?></p>
				<ul class="list-unstyled">
					<li>
						<i class="fa fa-unlock-alt fa-fw"></i>
						<span>Added Date </span>: <?php echo $item['Add_Date']; ?>
					</li> 
					<li>
						<i class="fa fa-money-bill-wave fa-fw"></i>
						<span>Price </span>: <?php echo $item['Price']; ?></li>
					<li>
						<i class="fa fa-building fa-fw"></i>
						<span>Made In  </span>: <?php echo $item['Country_Made']; ?></li>
					<li>
						<i class="fa fa-tags fa-fw"></i>
						<span>Category Name </span>: <a href="categories.php?pageid=<?php echo $item['Cat_ID']; ?>"><?php echo  $item['Category_Name']; ?></a>
					</li>
					<li>
						<i class="fa fa-user fa-fw"></i>
						<span>Added By </span>: <a href="#"><?php echo $item['Username']; ?></a>
					</li>
					<li class="tags-item">
						<i class="fa fa-user fa-fw"></i>
						<span>Tags</span>: 
						<?php 
							$allTags = explode(",", $item['tags']);
							foreach ($allTags as $tag) {
								$tag = str_replace(' ', '', $tag);
								$tag = strtolower($tag);
								if(! empty($tag)){
									echo "<a href='tags.php?name={$tag}'>".$tag .'</a>';
								}
								
							}
						?>
					</li>
				</ul>
			</div>
		</div>
		<hr class="hrs">
		<?php if(isset($_SESSION['user'])){ ?>
			<!-- Start Add Comment For Items-->
			<div class="row">
				<div class="add-comment">
					<div class="col-md-offset-3 ">
					<h3>Add You Comment</h3>
					<form method="POST" action="<?php echo $_SERVER['PHP_SELF'].'?itemid='. $item['item_ID'] ; ?>">
						<textarea required="required" name="comment" class="form-control"></textarea>
						<input class="btn btn-primary" type="submit" value="Add Comment" name="">
					</form>
					<?php 
					if($_SERVER['REQUEST_METHOD'] == 'POST'){

						$comment = filter_var($_POST['comment'],FILTER_SANITIZE_STRING);
						$itemid  = $item['item_ID'];
						$userid  = $_SESSION['uid'];

						if(! empty($comment)){
							$stmt = $con->prepare("INSERT INTO 
													comments(comment,stuts,c_date,item_id,user_id)
													 Values 
													 (:zcomment,0,now(),:zitemid,:zuserid) ");
							$stmt->execute(array(

								'zcomment' => $comment, 
								'zitemid'  => $itemid,
								'zuserid'  => $userid
 							));
							if($stmt){
								echo "<div class='alert alert-success'>Comment Added</div>";
							}
						}

					}


					?>
				</div>
				</div>
			</div>
			<!-- End  Add Comment For Items -->
		<?php }else{// If Not Have Session To apply TO Add Comment

			echo 'You Should Make <a href="login.php">Login</a> To Add Comment ';


		} ?>
		<hr class="hrs">
			<?php
				// Select All Users Expect Admins
	            $stmt= $con->prepare("SELECT
	                                    comments.*,users.Username AS Member
	                                    From
	                                        comments
	                                    INNER JOIN
	                                    	users
	                                    ON 
	                                    	users.UserID = comments.user_id
	                                    WHERE
	                                    	item_ID = ?
	                                    AND 
	                                    	stuts = 1
	                                    ORDER BY 
	                                    	c_id DESC
	                                    ");
	            // Execute Sttatement
	            $stmt->execute(array($item['item_ID']));
	            // Assign To Variable
	            $comments = $stmt->fetchAll();

		        foreach ($comments as $comment) {
					echo "<div class='comment-box'>";
						echo '<div class="row">';
			        		echo "<div class='col-sm-2 text-center'>"; 
			        			echo "<img class='img-responsive img-circle img-thumbnail center-block' src='d.png' alt='User Image' />";
			        			echo $comment['Member'] ;
			        		echo "</div>";
			        		echo "<div class='col-sm-10'>";
			        			echo "<p class='lead' >" . $comment['comment'] . "</p>";
			        		echo "</div>";
		        		echo "</div>";  
					echo "</div>";  
					echo "<hr class='hrs'>";     	
        		}
	?>
	</div>
<?php
}else{
    echo "<div class= 'container'>";
    echo "<div class = 'alert alert-danger'>There's No Such ID Or This Item Waiting Approval</div>";
    echo "</div>";
}
// If isset User 	
  include $tpl .'footer.php';
  ob_end_flush();

 ?>