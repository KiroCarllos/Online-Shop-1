<?php
	include 'Admin/connect.php';
	// Routes
	$tpl = 'includes/template/';// Template Directly
	$lang = 'includes/languages/';// Language Directly
	$func = 'includes/functions/';// Function Directly
	$css = 'LayOut/css/';	// Css Directly
	$js = 'LayOut/js/';// JavaScript Directly



	$sessionUser ='' ;
	if(isset($_SESSION['user'])){

		$sessionUser = $_SESSION['user'] ;
	}

	// Include Important Files
	include $lang . 'english.php';
	include $func .'function.php';
	include $tpl . 'header.php';

	