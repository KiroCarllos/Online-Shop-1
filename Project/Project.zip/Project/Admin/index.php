<?php
	session_start();
  $noNav = '';
  $pageTitle = 'Login';

  if(isset($_SESSION['user'])){
    header('Location: index.php');
  }


	include 'init.php';	

	// Check User If User Come From HTTP Request

    if($_SERVER['REQUEST_METHOD']  == 'POST'){
        $user = $_POST['user'];
        $pass = $_POST['pass'];
        $hashedpass = sha1($pass);

       	// Check User If Exist In DB

        $stmt =$con->prepare("SELECT 
                                UserID,Username, Password
                                 From 
                                 users 
                                 WHERE 
                                 Username= ? 
                                 AND 
                                 Password = ? 
                                 And 
                                 GroupID = 1 
                                 LIMIT 1 "
                            );
        $stmt->execute(array($user,$hashedpass));
        $row = $stmt->fetch();
        $count = $stmt->rowCount();
        
        // If Count > 0 That Mean The Database Content This Record -- Username and Password

        if ($count > 0){
           		$_SESSION['Username'] = $user;//Register Session Name
              $_SESSION['ID'] = $row['UserID'];//Register Session ID
           			header('Location: dashboard.php');
           		exit();
        }
    }
?>
	<form class="login" action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST"> 
		<h4 class="text-center">Admin Login</h4> 
		<input type="text" class="form-control input-lg" name="user" placeholder="Enter Your UserName" autocomplete="false">
		<input type="password" class="form-control input-lg" name="pass" placeholder="Enter Your Password" autocomplete="false">
		<input type="submit" class="btn btn-primary btn-block input-lg" name="btn" value="Login">
	</form>


<?php include $tpl .'footer.php';?>