<?php
	/*
		=================================================
		== Manage Items Page
		== You Can Add | Edit | Delete Items From Here
		=================================================
	*/
	ob_start();
	session_start();
	$pageTitle = 'Items';
	if(isset($_SESSION['Username'])){

    	include 'init.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
		// Start Manage Page
		if ($do == 'Manage'){// Manage Page
            // Select All Users Expect Admins
            $stmt= $con->prepare("SELECT
                                    items.*,users.Username as UserName ,categories.Name as Cat_Name
                                    FROM 
                                        items 
                                    INNER JOIN 
                                        users
                                    ON users.UserID =items.Member_ID 
                                    INNER JOIN 
                                        categories
                                    ON categories.ID = items.Cat_ID
                                    ");
            // Execute Sttatement
            $stmt->execute();
            // Assign To Variable
            $items = $stmt->fetchAll();

           

            if(empty(! $items)){
            ?>
            <h1 class="text-center">Manage Items</h1>
            <div class="container">
                <div class="table-responsive">
                    <table class="main-table text-center table table-bordered">
                        <tr>
                            <td>#ID</td>
                            <td>Name</td>
                            <td>Description</td>
                            <td>Pricing</td>
                            <td>Adding Date</td>
                            <td>Category</td>
                            <td>UserName</td>
                            <td>Control</td>
                        </tr>
                        <?php 
                            foreach ($items as $item) {
                                echo "</tr>";
                                    echo "<td>" . $item['item_ID'] . "</td>";
                                    echo "<td>" . $item['Name'] . "</td>";
                                    echo "<td>" . $item['Description'] . "</td>";
                                    echo "<td>" . $item['Price'] . "</td>";
                                    echo "<td>" . $item['Add_Date'] . "</td>";
                                    echo "<td>" . $item['Cat_Name'] . "</td>";
                                    echo "<td>" . $item['UserName'] . "</td>";
                                    echo "<td>
                                        <a href='items.php?do=Edit&itemid=" .$item['item_ID']. "' class='btn btn-success'><i class='fa fa-edit'></i>  Edit</a>
                                        <a href='items.php?do=Delete&itemid=" .$item['item_ID']. "' class='btn btn-danger Confirm' ><i class='fa fa-window-close'></i> Delete</a>";
                                        if ($item['Approve'] == 0){
                                            echo "<a href='items.php?do=Approve&itemid=" .$item['item_ID']. "' class='btn btn-info activate' ><i class='fa fa-check'></i> Approve</a>";
                                        }
                                    echo "</td>";
                                echo "</tr>";
                            }
                        ?>
                    </table>
                </div>
                <a href='items.php?do=Add' class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add New Item </a>
            </div>
            <?php }else{
                    echo "<div class='container'>";
                    echo "<div class='nice-message'>There is No Items Recorded </div>";
                    echo '<a href="items.php?do=Add" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add New Item </a>';
                    echo "</div>";
            }  ?>
            <?php
    	}elseif($do == 'Add'){  // Add Page?>
            <!-- Add Members Page -->
            <h1 class="text-center"> Add New Item </h1>
            <div class="container">
                <form class="form-horizontal" action="?do=Insert" method="POST">
                    <!-- Start Name Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Name</label>
                        <div class="col-sm-10 col-md-6">
                            <input type="text" placeholder="Name Of Item" name="Name"  class="form-control" required="required">
                        </div>
                    </div>
                    <!-- End Name Input -->

                    <!-- Start Description Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Description</label>
                        <div class="col-sm-10 col-md-6">
                            <input type="text" placeholder="Description Of Item" name="Description"  class="form-control">
                        </div>
                    </div>
                    <!-- End Description Input -->

                    <!-- Start Price Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Price</label>
                        <div class="col-sm-10 col-md-6">
                            <input type="text" placeholder="Price Of Item" name="Price"  class="form-control" required="required" >
                        </div>
                    </div>
                    <!-- End Price Input -->

                    <!-- Start Country Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Country</label>
                        <div class="col-sm-10 col-md-6">
                            <input type="text" placeholder="Country Of Made" name="Country"  class="form-control" required="required">
                        </div>
                    </div>
                    <!-- End Country Input -->

                    <!-- Start Stutus Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Stutus</label>
                        <div class="col-sm-10 col-md-6">
                            <select class="form-control" name="stutus">
                                <option value="0">.....</option>
                                <option value="1">New</option>
                                <option value="2">Like</option>
                                <option value="3">Used</option>
                                <option value="4">Old</option>
                                <option value="5">Very Old</option>
                            </select>
                        </div>
                    </div>
                    <!-- End Stutus Input -->

                    <!-- Start Members Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Member</label>
                        <div class="col-sm-10 col-md-6">
                            <select class="form-control" name="member">
                                <option value="0">.....</option>
                                <?php
                                    $users = getAllFrom('*','users','','','UserID','');
                                    foreach($users as $user){
                                        echo "<option value='".$user['UserID']."'>".$user['Username']."</option>";
                                    }
                                ?>  
                            </select>
                        </div>
                    </div>
                    <!-- End Members Input -->


                    <!-- Start Category Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Category</label>
                        <div class="col-sm-10 col-md-6">
                            <select class="form-control" name="Category">
                                <option value="0">.....</option>
                                <?php
                                    $cats = getAllFrom('*','categories','Where parent = 0','','ID','');
                                    foreach($cats as $cat){
                                        echo "<option value='".$cat['ID']."'>".$cat['Name']."</option>";
                                        $Childcats = getAllFrom("*","categories","Where parent = {$cat['ID']}","","ID","");
                                        foreach ($Childcats as $ch) {
                                            echo "<option value='".$ch['ID']."'>---".$ch['Name']."</option>";

                                        }
                                    }
                                ?>  
                            </select>
                        </div>
                    </div>
                    <!-- End Category Input -->


                    <!-- Start Tags Input -->
                    <div class="form-group form-group-lg">
                        <label class="col-sm-2 control-label">Tags</label>
                        <div class="col-sm-10 col-md-6">
                            <input type="text" placeholder="Separate Tags With Comma (,) " name="tags"  class="form-control">
                        </div>
                    </div>
                    <!-- End Tags Input -->



                    <!-- Start Submit Input -->
                    <div class="form-group form-group-lg">
                        <div class="col-sm-offset-2 col-sm-10">
                            
                            <input type="submit" value='Save Item' name="" class=" btn btn-primary btn-sm">
                           
                        </div>
                    </div>
                   
                </form>
            </div>
             <!-- End Submit Input ///////////////////////////////////-->
            <?php 

		}elseif($do == 'Insert'){ // Insert Items
                if($_SERVER['REQUEST_METHOD'] == 'POST'){
                echo "<h1 class='text-center'> Add New Items </h1>";
                echo "<div class='container'>";
                // Get Variables From Forms 
                $name           = $_POST['Name'];
                $desc           = $_POST['Description'];
                $price          = $_POST['Price'];
                $country        = $_POST['Country'];
                $stutus         = $_POST['stutus'];
                $member         = $_POST['member'];
                $category       = $_POST['Category'];
                $tags           = $_POST['tags'];

                
                // Validate The Form
                $FormError = array();

                if(empty($name)){
                    $FormError[] = " Name cant be <strong> empty </strong>";
                    
                }
                if(empty($price)){
                    $FormError[] = " Price cant be <strong> empty </strong>";
                    
                }
                if(empty($country)){
                    $FormError[] = " Country cant be <strong> empty </strong>";
                    
                }
                if($stutus == 0){
                    $FormError[] = " You Must Choose The Stutus As it cant be <strong> empty </strong>";
                    
                }
                if($member == 0){
                    $FormError[] = " You Must Choose The Member As it cant be <strong> empty </strong>";
                    
                }
                if($category == 0){
                    $FormError[] = " You Must Choose The Category As it cant be <strong> empty </strong>";
                    
                }
                foreach ($FormError as $Error) {
                    echo "<div class='alert alert-danger'>" . $Error . "</div>";
                }
                // Check if no error procede to continue update
                if(empty($FormError)){
                    // Insert Item Data
                    $stmt = $con->prepare('INSERT INTO 
                                            items 
                                            (Name,Description,Price,Country_Made,Stutus,Add_Date,Cat_ID,Member_ID,tags)
                                            Values 
                                            (:name,:descr,:price,:country,:stutus,now(),:catid,:membid,:tags);');
                    $stmt->execute(array(
                            'name'   => $name,    
                            'descr'  =>  $desc,   
                            'price'  => $price,
                            'country'=> $country,
                            'stutus' => $stutus,
                            'catid'  => $category,
                            'membid' => $member,
                            'tags'   => $tags));
                        // Echo Sucess Message
                        echo "<div class='alert alert-success'>" .$stmt->rowCount()." "." Record Inserted </div>";
                    }else{
                         echo "<div class= 'container'>";
                        $msg = "<div class = 'alert alert-danger'>Faild Add The Data Of Item</div>";
                        redirectHome($msg,'back',6);
                        echo "</div>";
                    }            
                }else{
                echo "<div class= 'container'>";
                $msg = "<div class = 'alert alert-danger' >You Cant Browse This Page Directly</div>";
                redirectHome($msg,'back',6);
                echo "</div>";
                }
                echo "</div>";

		}elseif ($do == 'Edit') { // Edit Page

                // Condition To Get UserID Successfully
                $itemid = isset($_GET['itemid']) && is_numeric($_GET['itemid']) ? intval($_GET['itemid']) : 0;
                // Select All Data Depend To UserID
                $stmt =$con->prepare("SELECT * From items WHERE item_ID= ? LIMIT 1 "
                                    );
                // Execute Query
                $stmt->execute(array($itemid));
                // Print In Array
                $item = $stmt->fetch();
                // Check if User Not Exist
                $count = $stmt->rowCount();
                // mY Condition
                if($count > 0){ ?>
                    <!-- Add Members Page -->
                    <h1 class="text-center"> Edit Item </h1>
                    <div class="container">
                        <form class="form-horizontal" action="?do=Update" method="POST">
                            <input type="hidden" name="itemid" value="<?php echo($itemid)?>">
                            <!-- Start Name Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Name</label>
                                <div class="col-sm-10 col-md-6">
                                    <input type="text" placeholder="Name Of Item" name="Name"  class="form-control" required="required" value="<?php echo($item['Name'])?>">
                                </div>
                            </div>
                            <!-- End Name Input -->

                            <!-- Start Description Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Description</label>
                                <div class="col-sm-10 col-md-6">
                                    <input type="text" placeholder="Description Of Item" name="Description"  class="form-control"  value="<?php echo($item['Description'])?>">
                                </div>
                            </div>
                            <!-- End Description Input -->

                            <!-- Start Price Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Price</label>
                                <div class="col-sm-10 col-md-6">
                                    <input type="text" placeholder="Price Of Item" name="Price"  class="form-control" required="required"  value="<?php echo($item['Price'])?>">
                                </div>
                            </div>
                            <!-- End Price Input -->

                            <!-- Start Country Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Country</label>
                                <div class="col-sm-10 col-md-6">
                                    <input type="text"
                                            placeholder="Country Of Made" 
                                            name="Country"  class="form-control" 
                                            required="required"  
                                            value="<?php echo($item['Country_Made'])?>">
                                </div>
                            </div>
                            <!-- End Country Input -->

                            <!-- Start Stutus Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Stutus</label>
                                <div class="col-sm-10 col-md-6">
                                    <select class="form-control" name="stutus">
                                        <option value="1" <?php if ($item['Stutus'] == 1) {echo "selected";} ?>>New</option>
                                        <option value="2" <?php if ($item['Stutus'] == 2) {echo "selected";} ?>>Like</option>
                                        <option value="3" <?php if ($item['Stutus'] == 3) {echo "selected";} ?>>Used</option>
                                        <option value="4" <?php if ($item['Stutus'] == 4) {echo "selected";} ?>>Old</option>
                                        <option value="5" <?php if ($item['Stutus'] == 5) {echo "selected";} ?>>Very Old</option>
                                    </select>
                                </div>
                            </div>
                            <!-- End Stutus Input -->

                            <!-- Start Members Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Member</label>
                                <div class="col-sm-10 col-md-6">
                                    <select class="form-control" name="member">
                                        <?php
                                            $users=getAllFrom('*','users','','','UserID','');
                                            foreach($users as $user){
                                                echo "<option value='".$user['UserID']."'";
                                                if ($item['Member_ID'] == $user['UserID']) {
                                                    echo 'selected';}
                                                 echo ">".$user['Username']."</option>";
                                            }
                                        ?>  
                                    </select>
                                </div>
                            </div>
                            <!-- End Members Input -->


                            <!-- Start Category Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Category</label>
                                <div class="col-sm-10 col-md-6">
                                    <select class="form-control" name="Category">
                                        <?php
                                            $cats = getAllFrom('*','categories','','','ID','');
                                            foreach($cats as $cat){
                                                echo "<option value='".$cat['ID']."'";
                                                if ($item['Cat_ID'] == $cat['ID']) {
                                                    echo 'selected';}
                                                echo ">".$cat['Name']."</option>";
                                            }
                                        ?>  
                                    </select>
                                </div>
                            </div>
                            <!-- End Category Input -->

                            <!-- Start Tags Input -->
                            <div class="form-group form-group-lg">
                                <label class="col-sm-2 control-label">Tags</label>
                                <div class="col-sm-10 col-md-6">
                                    <input type="text" 
                                            placeholder="Separate Tags With Comma (,) " 
                                            name="tags"  
                                            class="form-control"
                                            value="<?php echo($item['tags'])?>">
                                </div>
                            </div>
                            <!-- End Tags Input -->

                            <!-- Start Submit Input -->
                            <div class="form-group form-group-lg">
                                <div class="col-sm-offset-2 col-sm-10">
                                    
                                    <input type="submit" value='Save Item' name="" class=" btn btn-primary btn-sm">
                                   
                                </div>
                            </div>
                            <!-- End Submit Input -->

                        </form>
                <?php
                $stmt= $con->prepare("SELECT
                                        comments.* ,users.Username AS Owner_Comment
                                        From
                                            comments
                                        INNER JOIN
                                            users
                                        ON 
                                            users.UserID = comments.user_id
                                        WHERE
                                            item_id = ?
                                        ");
                // Execute Sttatement
                $stmt->execute(array($itemid));
                // Assign To Variable
                $rows = $stmt->fetchAll();
                if (! empty($rows)){
                    ?>
                    <h1 class="text-center">Mange [ <?php echo($item['Name'])?> ] Comment</h1>
                    <div class="table-responsive">
                        <table class="main-table text-center table table-bordered">
                            <tr>
                                <td>Comments</td>
                                <td>Added Data</td>
                                <td>Stutus</td>
                                <td>Whose</td>
                                <td>Control</td>
                            </tr>
                            <?php 
                            if(! empty($rows)){
                                    foreach ($rows as $row) {
                                        echo "</tr>";
                                            echo "<td>" . $row['comment'] . "</td>";
                                            echo "<td>" . $row['c_date'] . "</td>";
                                            echo "<td>" . $row['stuts'] . "</td>";
                                            echo "<td>" . $row['Owner_Comment'] . "</td>";

                                            echo "<td>
                                                <a href='comments.php?do=Edit&commentid=" .$row['c_id']. "' class='btn btn-success'><i class='fa fa-edit'></i>  Edit</a>
                                                <a href='comments.php?do=Delete&commentid=" .$row['c_id']. "' class='btn btn-danger Confirm' ><i class='fa fa-window-close'></i>  Delete</a>";
                                                
                                            if($row['stuts'] == 0){

                                                echo "<a href='comments.php?do=Approve&commentid=" .$row['c_id']. "' class='btn btn-info activate' ><i class='fa fa-check'></i>  Approve</a>";
                                            }

                                            echo "</td>";
                                        echo "</tr>";
                                    }
                                }else{
                                        echo "<div class= 'container'>";
                                        $msg = "<div class='alert alert-danger' >Your Account ID Not Found</div>";
                                        echo '<a href="items.php?do=Add" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i> Add New Item </a>';
                                        echo "</div>";
                                }
                            ?>
                        </table>
                    </div>
                    <a href='comments.php?do=Add' class="btn btn-primary"><i class="fa fa-plus"></i> Add New Comment </a>
                    <?php }else{
                                
                    } ?> 
                    <?php 
         
                // Show Error IF Not Found UserID
                }else{
                    echo "<div class= 'container'>";
                    $msg = "<div class='alert alert-danger' >Your Account ID Not Found</div>";
                    redirectHome($msg,'back',3);
                    echo "</div>";


                }
            

		}elseif($do == 'Update'){// Update Members

            echo "<h1 class='text-center'> Update Item </h1>";

            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                    // Get Variables From Forms
                $id      = $_POST['itemid'];
                $Name    = $_POST['Name'];
                $desc    = $_POST['Description'];
                $Price   = $_POST['Price'];
                $Country = $_POST['Country'];
                $Stutus  = $_POST['stutus'];
                $memb    = $_POST['member'];
                $cat     = $_POST['Category'];
                $tags    = $_POST['tags'];
                // Validate The Form
                $FormError = array();

                if(empty($Name)){
                    $FormError[] = " Name cant be <strong> empty </strong>";
                    
                }
                if(empty($Price)){
                    $FormError[] = " Price cant be <strong> empty </strong>";
                    
                }
                if(empty($Country)){
                    $FormError[] = " Country cant be <strong> empty </strong>";
                    
                }
                if($Stutus == 0){
                    $FormError[] = " You Must Choose The Stutus As it cant be <strong> empty </strong>";
                    
                }
                if($memb == 0){
                    $FormError[] = " You Must Choose The Member As it cant be <strong> empty </strong>";
                    
                }
                if($cat == 0){
                    $FormError[] = " You Must Choose The Category As it cant be <strong> empty </strong>";
                    
                }
                foreach ($FormError as $Error) {
                    echo "<div class='alert alert-danger'>" . $Error . "</div>";
                }
                if(empty($FormError)){

                    // Update User Data
                    $stmt = $con->prepare("UPDATE 
                                                items 
                                          SET
                                        Name = ?,Description = ? ,Price = ?, Country_Made = ?,Stutus=?,Cat_ID=?,Member_ID=?,tags = ? 
                                          Where
                                                item_ID = ?");
                    $stmt->execute(array($Name,$desc,$Price,$Country,$Stutus,$cat,$memb,$tags,$id));
                    // Echo Sucess Message
                    if ($stmt->rowCount() == 1){
                        echo "<div class = 'container'>";
                            $msg = "<div class='alert alert-success'>" . $stmt->rowCount()." ". "Sucess Updated </div>";

                        redirectHome($msg,'back',3);
                        echo "</div>";
                    }else{
                        echo "<div class = 'container'>";
                        $msg = "<div class='alert alert-danger'>" . $stmt->rowCount()." ". "Faild Updated </div>";

                        redirectHome($msg,'back',3);
                        echo "</div>";
                    }
        
                }
            }   

		}elseif($do == 'Delete'){// Update Members
                echo "<h1 class='text-center'> Delete Item </h1>";
                echo "<div class='container'>";
                // Condition To Get UserID Successfully
                $itemid = isset($_GET['itemid']) && is_numeric($_GET['itemid']) ? intval($_GET['itemid']) : 0;
                    // Select All Data Depend To UserID
                $stmt =$con->prepare("SELECT * From items WHERE item_ID= ? LIMIT 1 ");
                // Execute Query
                $stmt->execute(array($itemid));
                // Print In Array
                $row = $stmt->fetch();
                // Check if User Not Exist
                $count = $stmt->rowCount();
                // mY Condition
                if($count > 0){ 
                    $stmt=$con->prepare("DELETE From items WHERE item_ID =:zditem");
                    
                    $stmt->bindParam(":zditem",$itemid);

                    $stmt->execute();
                    if ($stmt->rowCount() == 1 ){
                        echo "<div class= 'container'>";
                        $msg = "<div class= 'alert alert-success'>Record Deleted</div>";
                        redirectHome($msg,'back',3);
                        echo "</div>";
                    }else{
                        echo "<div class= 'container'>";
                        $msg = "<div class= 'alert alert-danger'>Failed Record Deleted</div>";
                        redirectHome($msg,'back',3);
                        echo "</div>";
                    }

                }else{
                    echo "<div class= 'container'>";
                    $msg = "<div class= 'alert alert-danger'>Your ID Not Found </div>";
                    redirectHome($msg,'back',3);
                    echo "</div>";
                    }
                    echo "</div>";

        }elseif($do == 'Approve'){
            echo "<h1 class='text-center'> Approve Item </h1>";
            echo "<div class='container'>";
            // Condition To Get UserID Successfully
            $itemid = isset($_GET['itemid']) && is_numeric($_GET['itemid']) ? intval($_GET['itemid']) : 0;
                // Select All Data Depend To UserID
                $stmt =$con->prepare("SELECT * From items WHERE item_ID= ? LIMIT 1 "
                                    );
                // Execute Query
                $stmt->execute(array($itemid));
                // Print In Array
                $row = $stmt->fetch();
                // Check if User Not Exist
                $count = $stmt->rowCount();
                // mY Condition
                if($count > 0){ 

                    $stmt=$con->prepare("UPDATE items SET Approve = 1 WHERE item_ID = ?");
                    $stmt->execute(array($itemid));
                    $count = $stmt->rowCount();
                    if ($count == 1 ){
                        echo "<div class= 'container'>";
                        $msg = "<div class= 'alert alert-success'>Record Activated</div>";
                        redirectHome($msg,'back',3);
                        echo "</div>";
                    }else{
                        echo "<div class= 'container'>";
                        $msg = "<div class= 'alert alert-danger'>Failed Record Activated</div>";
                        redirectHome($msg,'back',3);
                        echo "</div>";
                    }

                    }else{

                    echo "<div class= 'container'>";
                    $msg = "<div class= 'alert alert-danger'>Your ID Not Found </div>";
                    redirectHome($msg,'back',3);
                    echo "</div>";
                    }
                    echo "</div>";

        }else{

        }
    	include $tpl .'footer.php';
	}else{
		header("Location: index.php");
		exit();
	}

	ob_end_flush();

?>