<?php
	/*
		=================================================
		== Manage Members Page
		== You Can Add | Edit | Delete Members From Here
		=================================================
	*/
	ob_start();
	session_start();
	$pageTitle = 'Categories';
	if(isset($_SESSION['Username'])){

    	include 'init.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
		// Start Manage Page
		if ($do == 'Manage'){// Manage Page

            $sort = 'DESC';

            $sort_array = array('ASC','DESC');

            if (isset($_GET['sort']) && in_array($_GET['sort'],$sort_array)) {
                
                $sort = $_GET['sort'];
            }

			$stmt = $con->prepare("SELECT * FROM categories Where parent =0 ORDER BY Ordering $sort");

			$stmt->execute();

			$cats= $stmt->fetchAll(); ?>

			<h1 class="text-center">Mange Categories</h1>
			<div class="container categories">
				<div class="panel panel-default">
					<div class="panel panel-heading"><i class="fa fa-edit"></i> Mange Categories
                        <div class="option pull-right">
                            <i class="fa fa-sort"></i> Ordering:[
                            <a class="<?php if ($sort == 'ASC' ){echo 'active' ;} ?>" href="?sort=ASC">ASC</a> |
                            <a class="<?php if ($sort == 'DESC' ){echo 'active' ;} ?>" href="?sort=DESC">DESC</a> ]
                            <i class="fa fa-eye"></i> view: [
                            <span class="active" data-view="Full">Full</span> |
                            <span data-view="Classic">Classic</span> ]
                        </div>
                    </div>
					<div class="panel panel-body">
						<?php 
						foreach ($cats as $cat){
    							echo "<div class='cat'>";

    								echo "<div class='hidden-buttons'>";
                                    echo "<a href='categories.php?do=Delete&catid=".$cat['ID']."' class='btn btn-danger Confirm' ><i class='fa fa-window-close'></i> Delete</a>";
    									echo "<a href='categories.php?do=Edit&catid=".$cat['ID'] ."' class='btn btn-xs btn-primary'><i class='fa fa-edit'></i> Edit</a>";
    								echo "</div>";

    								echo "<h3>" . $cat['Name'] . "</h3>";
                                    echo "<div class='full-view'>";
        	                            echo "<p>";if( $cat['Description'] == ''){echo "The Description is Empty";}else{echo $cat['Description'];} echo "</p>";
        	                            if($cat['Visability'] == 1){echo "<span class='Visibility'><i class='fa fa-eye'></i>Hidden</span>";} 
        	                            if($cat['Allow_Comment'] == 1){echo "<span class='Comment'><i class='fa fa-window-close'></i> Comment is Disable </span>";} 
        	                            if($cat['Allow_Ads'] == 1){echo "<span class='Advertising'><i class='fa fa-window-close'></i> Advertising is Disabled </span>";} 
                                    echo "</div>";
                                    $getCategories =getAllFrom("*","categories","Where parent ={$cat['ID']}","","ID") ;           
                                    if(! empty($getCategories)){
                                        echo "<h4 class='child-head'>Child Categories</h4>";
                                        foreach ($getCategories as $c) {
                                        echo "<ul class='list-unstyled child-cats'>";    
                                            echo  "<li class='child-link'>
                                                        <a href='categories.php?do=Edit&catid=".$c['ID']."' >".$c['Name'] ."</a>".
                                                        "<a href='categories.php?do=Delete&catid=".$c['ID']."' class='show-delete Confirm'>Delete</a>".
                                                   '</li>';
                                        echo "</ul>";
                                        }

                                    }
                
                                    echo "</div>";
                                    echo "<hr>";


						}// echo "<a href='categories.php?do=Delete&catid=" . $cat['ID'] ."' class='btn btn-xs btn-danger'><i class='fa fa-window-close'></i>Delete</a>";
						?>
					</div>
				</div>
                <a class="btn btn-primary add-category" href="categories.php?do=Add"><i class='fa fa-plus'></i> Add New Categoey </a>
			</div>

			<?php
    	}elseif($do =='Delete'){// Delete Members
                echo "<h1 class='text-center'> Delete Categoey</h1>";
                echo "<div class='container'>";
                // Condition To Get catid Successfully
                $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
                echo '<input type="hidden" name="catid" value="<?php echo $catid ?>">';
                // Select All Data Depend To catid
                $stmt =$con->prepare("SELECT * From categories WHERE ID= ? LIMIT 1 "
                                    );
                // Execute Query
                $stmt->execute(array($catid));
                // Print In Array
                $row = $stmt->fetch();
                // Check if User Not Exist
                $count = $stmt->rowCount();
                // mY Condition
                    if($count > 0){ 

                        $stmt=$con->prepare("DELETE From categories WHERE ID =:zuser");
                        
                        $stmt->bindParam(":zuser",$catid);

                        $stmt->execute();

                
                        if ($stmt->rowCount() == 1 ){
                            echo "<div class= 'container'>";
                            $msg = "<div class= 'alert alert-success'>Record Deleted</div>";
                            redirectHome($msg,'back',3);
                            echo "</div>";
                        }else{
                            echo $catid;
                            echo "<div class= 'container'>";
                            $msg = "<div class= 'alert alert-danger'>Failed Record Deleted</div>";
                            redirectHome($msg,'back',3);
                            echo "</div>";
                        }

                }else{

                        echo "<div class= 'container'>";
                        $msg = "<div class= 'alert alert-danger'>Your ID Not Found </div>";
                        redirectHome($msg,'back',3);
                        echo "</div>";
                        }     
        }elseif($do == 'Add'){  // Add Page ?>

    			<!-- Add Members Page -->
    			<h1 class="text-center"> Add New Category </h1>
    			<div class="container">
    				<form class="form-horizontal" action="?do=Insert" method="POST">
    					<!-- Start Category Input -->
    					<div class="form-group form-group-lg">
    						<label class="col-sm-2 control-label">Name</label>
    						<div class="col-sm-10 col-md-6">
    							<input type="text" placeholder="Name Of Category" name="Name" autocomplete="off"  class="form-control" required="required">
    						</div>
    					</div>
    					<!-- End Category Input -->

    					<!-- Start Description  Input -->
    					<div class="form-group form-group-lg">
    						<label class="col-sm-2 control-label">Description</label>
    						<div class="col-sm-10 col-md-6">
    							<input type="text" name="description" placeholder="Enter Your Description Of Category"  class="form-control">
    						</div>
    					</div>
    					<!-- End Description Input -->

    					<!-- Start Ordering Input -->
    					<div class="form-group form-group-lg">
    						<label class="col-sm-2 control-label">Ordering</label>
    						<div class="col-sm-10 col-md-6">
    							<input type="text" placeholder="Number Of Arrange Category" name="ordering" class="form-control">
    						</div>
    					</div>
    					<!-- End Ordering Input -->

                        <!-- Start Category Type -->
                        <div class="form-group form-group-lg">
                            <label class="col-sm-2 control-label">Parent ?</label>
                            <div class="col-sm-10 col-md-6">
                               <select class="form-control" name="parent">  
                                   <option value="0"> None </option>
                                   <?php 
                                   $all = getAllFrom('*','categories','Where parent = 0','','ID','');
                                   foreach ($all as $cat) {
                                        echo '<option value="'.$cat['ID'] .'">'.$cat['Name'].'</option>';
                                   }
                                   ?>
                               </select> 
                            </div>
                        </div>
                        <!-- End Category Type -->

                        <!-- Start Category Type -->



                        <!-- End Category Type -->



    					<!-- Start Visibility Input -->
    					<div class="form-group form-group-lg">
    						<label class="col-sm-2 control-label">Visible</label>
    						<div class="col-sm-10 col-md-6">
    							<div>
    								<input id="vis-yes" type="radio" name="Visibility" value="0" checked>
    								<label for="vis-yes">Yes</label>
    							</div>
    							<div>
    								<input id="vis-no" type="radio" name="Visibility" value="1" >
    								<label for="vis-no" >No</label>
    							</div>
    						</div>
    					</div>
    					<!-- End Visibility Input -->
    					<!-- Start Commenting Feiled Input -->
    					<div class="form-group form-group-lg">
    						<label class="col-sm-2 control-label">Allow Commenting</label>
    						<div class="col-sm-10 col-md-6">
    							<div>
    								<input id="com-yes" type="radio" name="commenting" value="0" checked>
    								<label for="com-yes">Yes</label>
    							</div>
    							<div>
    								<input id="com-no" type="radio" name="commenting" value="1" >
    								<label for="com-no" >No</label>
    							</div>
    						</div>
    					</div>
    					<!-- End Commenting Feiled Input -->

    					<!-- Start Allow Ads Input -->
    					<div class="form-group form-group-lg">
    						<label class="col-sm-2 control-label">Allow Advertising</label>
    						<div class="col-sm-10 col-md-6">
    							<div>
    								<input id="ads-yes" type="radio" name="ads" value="0" checked>
    								<label for="ads-yes">Yes</label>
    							</div>
    							<div>
    								<input id="ads-no" type="radio" name="ads" value="1" >
    								<label for="ads-no" >No</label>
    							</div>
    						</div>
    					</div>
    					<!-- End Allow Ads Input -->

    					<!-- Start Submit Input -->
    					<div class="form-group form-group-lg">
    						<div class="col-sm-offset-2 col-sm-10">
    							<input type="submit" value="Save Category"  name="Add Category" class=" btn btn-primary btn-lg">
    						</div>
    					</div>
    					<!-- End Submit Input -->

    				</form>
    			</div>
    			<?php 
		}elseif($do == 'Insert'){ // Insert Category
			 if($_SERVER['REQUEST_METHOD'] == 'POST'){
				echo "<h1 class='text-center'> INSERT Catedory</h1>";
				echo "<div class='container'>";
				// Get Variables From Forms	
	
				$name    		= $_POST['Name'];
				$description    = $_POST['description'];
				$ordering   	= $_POST['ordering'];
				$Visibility    	= $_POST['Visibility'];
				$commenting    	= $_POST['commenting'];
				$ads    		= $_POST['ads'];
                $parent         = $_POST['parent'];

				
				// Validate The Form
				$FormError = array();

				if(strlen($name) < 3){
					$FormError[] = "Name cant be less than<strong> 4 character</strong> ";
				}
				if(strlen($name) > 20){
					$FormError[] = "Name cant be More than<strong> 20 character </strong>";
				}
				if(empty($name)){
					$FormError[] = " Name cant be <strong> empty </strong>";
					
				}
					// Check If Category in database

					$check = CheckItem("Name","categories",$name);
					if( $check == 1){
						echo "<div class= 'container'>";
						$msg = "<div class= 'alert alert-danger' >Sorry Your Categories Excatly Found Same</div>";
						redirectHome($msg,'back',3);
						echo "</div>";

					}else{
							// Insert User Data
		                    $stmt = $con->prepare('INSERT INTO 
		                                            categories(Name,Description,Ordering,Visability,Allow_Comment,Allow_Ads,parent)
		                                            Values 
		                                            (:zname,:zdsc,:zord,:zvivible,:zcommt,:zadd,:zparent)');
		                    $stmt->execute(array(
		                        'zname' 	=> $name,
		                        'zdsc' 		=> $description,
		                        'zord' 		=> $ordering,
		                        'zvivible'  => $Visibility,
		                        'zcommt'    => $commenting,
		                        'zadd' 		=> $ads,
                                'zparent'   => $parent
		                    ));

							// Echo Sucess Message
							echo "<div class='alert alert-success'>" . $stmt->rowCount()." ". " Record Inserted </div>";
					}

				
					}else{
						echo "<div class= 'container'>";
						$msg = "<div class = 'alert alert-danger' >You Cant Browse This Page Directly</div>";
						redirectHome($msg,'back',6);
						echo "</div>";
					}
						echo "</div>";
		}elseif ($do == 'Edit') { // Edit Page
                // Condition To Get Cat ID Successfully
                $catid = isset($_GET['catid']) && is_numeric($_GET['catid']) ? intval($_GET['catid']) : 0;
                    // Select All Data Depend To UserID
                    $stmt =$con->prepare("SELECT * From categories WHERE ID= ? LIMIT 1 ");
                    // Execute Query
                    $stmt->execute(array($catid));
                    // Print In Array
                    $cat = $stmt->fetch();
                    // Check if cat Not Exist
                    $count = $stmt->rowCount();
                    // mY Condition
                    if($count > 0){ ?>
                            <h1 class="text-center"> Edit Categories </h1>
                            <div class="container">
                            <form class="form-horizontal" action="?do=Update" method="POST">
                            <input type="hidden" name="catid" value="<?php echo $catid ?>">
                                <!-- Start Category Input -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Name</label>
                                    <div class="col-sm-10 col-md-6">
                                        <input type="text" placeholder="Name Of Category" name="Name" autocomplete="off"  class="form-control" required="required" value="<?php echo $cat['Name']; ?>">
                                    </div>
                                </div>
                                <!-- End Category Input -->

                                <!-- Start Description  Input -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Description</label>
                                    <div class="col-sm-10 col-md-6">
                                        <input type="text" name="description" value="<?php echo $cat['Description']; ?>" placeholder="Enter Your Description Of Category"  class="form-control">
                                    </div>
                                </div>
                                <!-- End Description Input -->

                                <!-- Start Ordering Input -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Ordering</label>
                                    <div class="col-sm-10 col-md-6">
                                        <input type="text" value="<?php echo $cat['Ordering']; ?>" placeholder="Number Of Arrange Category" name="ordering" class="form-control">
                                    </div>
                                </div>
                                <!-- End Ordering Input -->


                                <!-- Start Category Type -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Parent ?</label>
                                    <div class="col-sm-10 col-md-6">
                                       <select class="form-control" name="parent">  
                                           <option value="0"> None </option>
                                           <?php 
                                           $all = getAllFrom('*','categories','Where parent = 0','','ID','');
                                           foreach ($all as $f) {
                                                echo "<option value='".$f['ID'] ."'";
                                                if($cat['parent'] == $f['ID']){
                                                    echo 'selected';
                                                }
                                                echo ">".$f['Name'].'</option>';
                                           }
                                           ?>
                                       </select> 
                                    </div>
                                </div>
                                <!-- End Category Type -->




                                <!-- Start Visibility Input -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Visible</label>
                                    <div class="col-sm-10 col-md-6">
                                        <div>
                                            <input id="vis-yes" type="radio" name="Visibility" value="0"<?php if($cat['Visability'] == 0){echo 'checked';} ?>>
                                            <label for="vis-yes">Yes</label>
                                        </div>
                                        <div>
                                            <input id="vis-no" type="radio" name="Visibility" value="1" <?php if($cat['Visability'] == 1){echo 'checked';} ?>>
                                            <label for="vis-no" >No</label>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Visibility Input -->



                                <!-- Start Commenting Feiled Input -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Allow Commenting</label>
                                    <div class="col-sm-10 col-md-6">
                                        <div>
                                            <input id="com-yes" type="radio" name="commenting" value="0" <?php if($cat['Allow_Comment'] == 0){echo 'checked';} ?>>
                                            <label for="com-yes">Yes</label>
                                        </div>
                                        <div>
                                            <input id="com-no" type="radio" name="commenting" value="1" <?php if($cat['Allow_Comment'] == 1){echo 'checked';} ?> >
                                            <label for="com-no" >No</label>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Commenting Feiled Input -->

                                <!-- Start Allow Ads Input -->
                                <div class="form-group form-group-lg">
                                    <label class="col-sm-2 control-label">Allow Advertising</label>
                                    <div class="col-sm-10 col-md-6">
                                        <div>
                                            <input id="ads-yes" type="radio" name="ads" value="0" <?php if($cat['Allow_Ads'] == 0){echo 'checked';} ?>>
                                            <label for="ads-yes">Yes</label>
                                        </div>
                                        <div>
                                            <input id="ads-no" type="radio" name="ads" value="1" <?php if($cat['Allow_Ads'] == 1){echo 'checked';} ?> >
                                            <label for="ads-no" >No</label>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Allow Ads Input -->

                                <!-- Start Submit Input -->
                                <div class="form-group form-group-lg">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <input type="submit" value="Save Category"  name="Add Category" class=" btn btn-primary btn-lg">
                                    </div>
                                </div>
                                <!-- End Submit Input -->

                            </form>
                        </div>
                    
                <?php 
                // Show Error IF Not Found UserID
                }else{
                echo "<div class= 'container'>";
                $msg = "<div class='alert alert-danger'>Your Account ID Not Found</div>";
                redirectHome($msg,'back',3);
                echo "</div>";
                }
		}elseif($do == 'Update'){// Update Members
            echo "<h1 class='text-center'> Update Category </h1>";

            if($_SERVER['REQUEST_METHOD'] == 'POST'){
                    // Get Variables From Forms
                $id      = $_POST['catid'];
                $Name    = $_POST['Name'];
                $desc   = $_POST['description'];
                $order    = $_POST['ordering'];
                $parent    = $_POST['parent'];
                $Visible    = $_POST['Visibility'];
                $commt    = $_POST['commenting'];
                $ads    = $_POST['ads'];
               
                // Update User Data
                $stmt = $con->prepare("UPDATE 
                                                categories 
                                            SET
                                                Name                = ?,
                                                Description         = ?,
                                                Ordering            = ?, 
                                                Visability          = ?,
                                                Allow_Comment       = ?, 
                                                Allow_Ads           = ?,
                                                parent              = ?
                                            Where 
                                                ID = ?");
                $stmt->execute(array($Name,$desc,$order,$Visible,$commt,$ads,$parent,$id));
                // Echo Sucess Message
                if ($stmt->rowCount() == 1){
                    echo "<div class = 'container'>";
                    $msg = "<div class='alert alert-success'>" . $stmt->rowCount() ." ". "Sucess Updated </div>";

                    redirectHome($msg,'back',3);
                    echo "</div>";
                }else{
                    echo "<div class = 'container'>";
                    $msg = "<div class='alert alert-danger'>".$stmt->rowCount()." ". "Sorry Updated Failed</div>";

                    redirectHome($msg,'back',3);
                    echo "</div>";
                }
            }
		}else{
                echo "<div class= 'container'>";
                $msg = "<div class= 'alert alert-danger' >Sorry Cant Browse This Page Directly</div>";
                redirectHome($msg,'back',3);
                echo "</div>";
        }
    	include $tpl .'footer.php';
	}else{
		header("Location: index.php");
		exit();
	}

	ob_end_flush();

?>