<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title><?php   getTitle()   ?></title>
		<link rel="stylesheet" href=<?php echo $css. "bootstrap.min.css"?>>
		<link rel="stylesheet" href=<?php echo $css. "all.css"?>>
		<link rel="stylesheet" href=<?php echo $css. "backend.css"?>>
	</head>
	<body>





