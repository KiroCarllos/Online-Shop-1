<?php 
	session_start();
	
	if(isset($_SESSION['Username'])){
  		$pageTitle = 'Dashboard';
		include 'init.php';

		// Start DashBoard Page

		$NumItems    = 6 ;
		$Ncomment    = 6 ;
		
		$latestItems =  getLatest("*","items","item_ID",$NumItems);
		$pc  = getLatest("*","comments","c_id",$Ncomment);
		?>
		<div class="container home-stats text-center">
			<h1>Dashboard</h1>
			<div class="row">
				<div class="col-md-3">
					<div class="stat st-Members">
						<i class="fa fa-users"></i>
						<div class="info ">
							Total Members
						<span><a href="members.php"><?php echo CountRows("UserID","users","UserID",'1 AND RegStutus = 1'); ?></a></span>
						</div>
					</div>	
				</div>

				<div class="col-md-3">
					<div class="stat st-Pending">
						<i class="fa fa-user-plus"></i>
						<div class="info">
							Pending Members
							<span><a href="members.php?do=Manage&Activate=Pending"><?php echo CheckItem("RegStutus","users",0); ?></a></span>
						</div>
					</div>	
				</div>

				<div class="col-md-3">
					<div class="stat st-Items">
						<i class="fa fa-tag"></i>
						<div class="info">
							Total Items
							<span><a href="items.php"><?php echo CountRows("item_ID","items"); ?></a></span>
						</div>
					</div>	
				</div>

				<div class="col-md-3">
					<div class="stat st-Comments">
						<i class="fa fa-comments"></i>
						<div class="info">
							Total Comments
							<span><a href="comments.php"><?php echo CountRows("c_id","comments"); ?></a></span>
						</div>
					</div>	
				</div>
			</div>

		</div>


		<!-- Start Users And Items Latest -->

		<div class="container latest">
			<div class="row">
				<div class="col-sm-6">
					<div class="panel panel-default">
						<?php $latestuser =6;?>
						<div class="panel-heading">
							<i class="fa fa-users"></i> Latest <?php echo $latestuser?> Registerd Users
							<span class="toggle-info pull-right">
								<i class="fa fa-minus fa-lg"></i>
							</span>
						</div>
						<div class="panel-body">
							<ul class="list-unstyled latest-user">
								<?php 
									$Latestuser = getLatest("*","users","UserID",$latestuser);
									if(!empty($Latestuser)){
										foreach ($Latestuser as $user){
											echo '<li class="Avtar-Img">';
											echo("<a href= 'members.php?do=Edit&UserID=".$user['UserID']."'>");
											if(!empty( $user['avatar'])){
												echo "<img src='Uploads\Avatars\\" . $user['avatar'] . "' alt = 'Avtar Img'/> ";

											}
											echo $user['Username'] ;
											echo "<span class='btn btn-success pull-right'><i class = 'fa fa-edit'></i>Edit";
	                                    		if($user['RegStutus'] == 0){

	                                    			echo "<a href='members.php?do=Activate&UserID=" .$user['UserID']. "' class='btn btn-info activate pull-right' ><i class='fa fa-window-close'></i>  Activate</a>";
	                                    		}
											echo "</span>";
											echo '</li>';
											echo "</a>";
										}
									}else{
										    // Message Tell There is NO Members Recorded
						            		echo "<div class='container'>";
						            		echo "<div class='nice-message'>There is No Members To Show </div>";
							            	echo "</div>";
									}
								?>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="panel panel-default">
						<div class="panel-heading">
							<i class="fa fa-tag"></i> Latest <?php echo $NumItems;?> Items
							<span class="toggle-info pull-right">
								<i class="fa fa-minus fa-lg"></i>
							</span>
						</div>
						<div class="panel-body">
							<ul class="list-unstyled latest-user">
								<?php 
									if(! empty($latestItems)){
										foreach ($latestItems as $item){
											echo '<li>';
											echo $item['Name'] ;
											echo("<a href= 'items.php?do=Edit&itemid=".$item['item_ID']."'>");
											echo "<span class='btn btn-success pull-right'><i class = 'fa fa-edit'></i>Edit";
	                                    		if($item['Approve'] == 0){

	                                    			echo "<a href='items.php?do=Approve&itemid=" .$item['item_ID']. "' class='btn btn-info activate pull-right' ><i class='fa fa-check'></i>  Approve</a>";
	                                    		}
											echo "</span>";
											echo '</li>';
											echo "</a>";
										}
									}else{
											// Message Tell There is NO Members Recorded
						            		echo "<div class='container'>";
						            		echo "<div>There is No Items To Show </div>";
							            	echo "</div>";
									}
								?>
							</ul>
						</div>
					</div>
				</div>

			</div>

		

		<!-- End Users And Items Latest -->

		<!-- Start Comment Latest -->
			<div class="row">
				<div class="col-sm-6">
					<div class="panel panel-default">
						<?php $latestuser = 6;?>
						<div class="panel-heading">
							<i class="fa fa-comments"></i> Latest <?php echo $Ncomment; ?> Comments
							<span class="toggle-info pull-right">
								<i class="fa fa-minus fa-lg"></i>
							</span>
						</div>
						<div class="panel-body">
							<?php
							   	$stmt= $con->prepare("SELECT
						                                    comments.*,users.Username AS Owner_Comment,users.avatar
						                                    From
						                                        comments
						                                    INNER JOIN
						                                    	users
						                                    ON 
						                                    	users.UserID = comments.user_id
						                                    ORDER BY c_id DESC
						                                    LIMIT $Ncomment
                                ");
							   	    // Execute Sttatement
						            $stmt->execute();
						            // Assign To Variable
						            $comments = $stmt->fetchAll();
						            if(! empty($comments)){
							            foreach($comments as $comment){
							            	echo "<div class='comment-box'>";
											if(!empty( $comment['avatar'])){
												echo "<img src='Uploads\Avatars\\" . $comment['avatar'] . "' alt = 'Avtar Img'/> ";

											}
							            		echo "<span class='member-n'>" . $comment['Owner_Comment'] . "</span>";
							            		echo "<p class='member-c'>" . $comment['comment'] . "</p>";
							  
							            	echo "</div>";
							            }
						            }else{
											// Message Tell There is NO Members Recorded
						            		echo "<div class='container'>";
						            		echo "<div>There is No Comments To Show </div>";
							            	echo "</div>";
						            }
							?>
						</div>
					</div>
				</div>
			</div>
		</div>


		<?php

		include $tpl .'footer.php';
	}else{
		header("Location: index.php");
		exit();
	}