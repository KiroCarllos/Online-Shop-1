<?php
	include 'connect.php';
	// Routes
	$tpl = 'includes/template/';// Template Directly
	$lang = 'includes/languages/';// Language Directly
	
	$func = 'includes/functions/';// Function Directly
	$css = 'LayOut/css/';	// Css Directly
	$js = 'LayOut/js/';// JavaScript Directly


	// Include Important Files
	include $lang . 'english.php';
	include $func .'function.php';
	include $tpl . 'header.php';
	
	
	// Include NavBar On All Pages Except One With $noNav Variable

	if(!isset($noNav)) {
		include $tpl . 'navbar.php';
	}