<?php
	/*
		=================================================
		== Manage Members Page
		== You Can Add | Edit | Delete Members From Here
		=================================================
	*/
	error_reporting(0);
	session_start();
	ob_start();
	$pageTitle = 'Members';
	if(isset($_SESSION['Username'])){

		include 'init.php';

		$do = isset($_GET['do']) ? $_GET['do'] : 'Manage';
			// Start Manage Page
		if ($do == 'Manage'){// Manage Page
			$Query = '';
			if(isset($_GET['Activate']) && $_GET['Activate'] == 'Pending'){
				$Query = 'AND RegStutus = 0';
			}

            // Select All Users Expect Admins
            $stmt= $con->prepare("SELECT
                                    *
                                    From
                                        users
                                    Where
                                    GroupID != 1 $Query");
            // Execute Sttatement
            $stmt->execute();
            // Assign To Variable
            $rows = $stmt->fetchAll();

            if(! empty($rows)){



            ?>
				
            <h1 class="text-center">Manage Members</h1>
            <div class="container">
                <div class="table-responsive">
                    <table class="main-table text-center table table-bordered">
                        <tr>
                            <td>#ID</td>
                            <td>Avatar</td>
                            <td>Username</td>
                            <td>Email</td>
                            <td>FullName</td>
                            <td>Registered Date</td>
                            <td>Control</td>
                        </tr>
                        <?php 
                            foreach ($rows as $row) {
                                echo "</tr>";
                                    echo "<td>" . $row['UserID'] . "</td>";
                                    echo "<td class='Avtar-Img'>";
                                    if(empty($row['avatar'])){
                                    	echo "No Image";
                                    }else{
	                                    echo "<img src='Uploads\Avatars\\" . $row['avatar'] . "' alt = 'Avtar Img'/>";

                                    }
                                    echo "</td>";
                                    echo "<td>" . $row['Username'] . "</td>";
                                    echo "<td>" . $row['Email'] . "</td>";
                                    echo "<td>" . $row['FullName'] . "</td>";
                                    echo "<td>"
                                    		. $row['Date'] .
                                          "</td>";
                                    echo "<td>
                                        <a href='members.php?do=Edit&UserID=" .$row['UserID']. "' class='btn btn-success'><i class='fa fa-edit'></i>  Edit</a>
                                        <a href='members.php?do=Delete&UserID=" .$row['UserID']. "' class='btn btn-danger Confirm' ><i class='fa fa-window-close'></i>  Delete</a>";
                                    	
                                    if($row['RegStutus'] == 0){

                                    	echo "<a href='members.php?do=Activate&UserID=" .$row['UserID']. "' class='btn btn-info activate' ><i class='fa fa-window-close'></i>  Activate</a>";
                                    }

                                    echo "</td>";
                                echo "</tr>";
                            }
                        ?>
                    </table>
                </div>
			    <a href='members.php?do=Add' class="btn btn-primary"><i class="fa fa-plus"></i> Add New Member </a>
            </div>
            <!--End OF if when No Have Members -->
            <?php }else{
            	// Message Tell There is NO Members Recorded
            	echo "<div class='container'>";
            		echo "<div class='nice-message'>There is No Members Recorded </div>";
	            	echo "<a href='members.php?do=Add' class='btn btn-primary'><i class='fa fa-plus'></i> Add New Member </a>";
	            	echo "</div>";
            } ?>
			<?php
			
		}elseif($do == 'Add'){ ?>
			<!-- Add Members Page -->
			<h1 class="text-center"> Add New Member </h1>
			<div class="container">
				<form class="form-horizontal" action="?do=Insert" method="POST" enctype="multipart/form-data">
					<!-- Start User Name Input -->
					<div class="form-group form-group-lg">
						<label class="col-sm-2 control-label">Username</label>
						<div class="col-sm-10 col-md-6">
							<input type="text" 
									placeholder="Enter Your Username" 
									name="Username" autocomplete="off"  
									class="form-control" 
									required="required">
						</div>
					</div>
					<!-- End Username Input -->

					<!-- Start Password  Input -->
					<div class="form-group form-group-lg">
						<label class="col-sm-2 control-label">Password</label>
						<div class="col-sm-10 col-md-6">
							<input type="Password" 
									autocomplete="password" 
									name="Password" 
									placeholder="Enter Your Complex Password" 
									class="password form-control" 
									required="required">
								<i class="show-pass fa fa-eye fa-2x"></i>
						</div>
					</div>
					<!-- End Password Input -->

					<!-- Start Email Input -->
					<div class="form-group form-group-lg">
						<label class="col-sm-2 control-label">Email</label>
						<div class="col-sm-10 col-md-6">
							<input type="email" 
									placeholder="Enter Your Valid Email" 
									autocomplete="off" 
									name="Email" 
									class="form-control" 
									required="required">
						</div>
					</div>
					<!-- End Email Input -->

					<!-- Start Full Name Input -->
					<div class="form-group form-group-lg">
						<label class="col-sm-2 control-label">Full Name</label>
						<div class="col-sm-10 col-md-6">
							<input type="text" 
									placeholder="Enter Your FullName" 
									autocomplete="off" 
									name="Full" 
									class="form-control" 
									required="required">
						</div>
					</div>
					<!-- End Full Input -->

					<!-- Start Upload Member Photo -->

					<div class="form-group form-group-lg">
						<label class="col-sm-2 control-label">User Picture</label>
						<div class="col-sm-10 col-md-6">
							<input type="file" 
									name="avatar" 
									class="form-control" 
									required="required">
						</div>
					</div>
					<!-- End Upload Member Photo -->


					<!-- Start Submit Input -->
					<div class="form-group form-group-lg">
						<div class="col-sm-offset-2 col-sm-10">
							<input type="submit" value="Add Member"  name="Submit" class=" btn btn-primary btn-lg">
						</div>
					</div>
					<!-- End Submit Input -->

				</form>
			</div>
			<?php 

		}elseif($do == 'Insert'){
			if($_SERVER['REQUEST_METHOD'] == 'POST'){
				echo "<h1 class='text-center'> Add New Member </h1>";
				echo "<div class='container'>";

				// Upload File Variables

				$avatarName = $_FILES['avatar']['name'];
				$avatarSize = $_FILES['avatar']['size'];
				$avatarTemp = $_FILES['avatar']['tmp_name'];
				$avatarType = $_FILES['avatar']['type'];

				// List Of Ententions File Upload 

				$avatarAllowedExtention = array('jpeg','png','jpg','gif');

				// Get Avatar Extentions and Compare it before save it



				$avatarExtention = strtolower(end(explode(".",$_FILES['avatar']['name'])));



				// Get Variables From Forms
	
				$user    = $_POST['Username'];
				$pass    = $_POST['Password'];
				$email   = $_POST['Email'];
				$Full    = $_POST['Full'];

				$hashpass= sha1($_POST['Password']);
				// Validate The Form
				$FormError = array();

				if(strlen($user) < 3){
					$FormError[] = "Username cant be less than<strong> 4 character</strong> ";
				}
				if(strlen($user) > 20){
					$FormError[] = "Username cant be More than<strong> 20 character </strong>";
				}
				if(empty($user)){
					$FormError[] = " Username cant be <strong>empty </strong>";
					
				}
				if(empty($pass)){
					$FormError[] = " Password cant be <strong> empty </strong>";
					
				}
				if(empty($email)){
					$FormError[] = " Email cant be <strong>empty</strong>";
				
				}
				if(empty($Full)){
					$FormError[] = " Email cant be <strong>empty</strong>";
				
				}
				if(!empty($avatarName) && ! in_array($avatarExtention, $avatarAllowedExtention)){

					$FormError[] = " This Extention <strong> Not Allowed </strong>";
				}
				if(empty($avatarName)){

					$FormError[] = " This Image Cant Be <strong> Empty </strong>";
				}
				if($avatarSize > 4194304) {

					$FormError[] = " This Image Cant Be More Than <strong> 4 </strong> MB";
				}
				// Loop Print Errors And Echo It
				foreach ($FormError as $Error) {
					echo "<div class='alert alert-danger'>" . $Error . "</div>";
				}
			
				// Check if no error procede to continue update
				if(empty($FormError)){
					// Check If User Exist in DataBase
				
					$Avatar = rand(0,10000000000000000) .'_' .$avatarName ;
					move_uploaded_file($avatarTemp, 'Uploads\Avatars\\'.$Avatar);
				
					$value = $user;

					$check = CheckItem("Username","users",$value);

					if( $check == 1){
						echo "<div class= 'container'>";
						$msg = "<div class= 'alert alert-danger' >Sorry Your Username Excatly Found Same</div>";
						redirectHome($msg,'back',3);
						echo "</div>";

					}else{
					// Insert User Data
                    $stmt = $con->prepare('INSERT INTO 
                                            users(Username,Password,Email,FullName,RegStutus,Date,avatar)
                                            Values (:zuser,:zpass,:zemail,:fullname,1,now(),:zavatar)');
                    $stmt->execute(array(
                        'zuser' 	=> $user,
                        'zpass' 	=> $hashpass,
                        'zemail'    => $email,
                        'fullname'  => $Full,
                   		'zavatar'	=> $Avatar));	

					// Echo Sucess Message
					echo "<div class='alert alert-success'>" . $stmt->rowCount()." ". " Record Inserted </div>";
					}

				}
			}else{
				echo "<div class= 'container'>";
				$msg = "<div class = 'alert alert-danger' >You Cant Browse This Page Directly</div>";
				redirectHome($msg,'back',6);
				echo "</div>";
			}
			echo "</div>";

		}elseif ($do == 'Edit') { // Edit Page
				// Condition To Get UserID Successfully
				$userid = isset($_GET['UserID']) && is_numeric($_GET['UserID']) ? intval($_GET['UserID']) : 0;
					// Select All Data Depend To UserID
					$stmt =$con->prepare("SELECT * From users WHERE UserID= ? LIMIT 1 "
										);
					// Execute Query
					$stmt->execute(array($userid));
					// Print In Array
					$row = $stmt->fetch();
					// Check if User Not Exist
					$count = $stmt->rowCount();
					// mY Condition
					if($count > 0){ ?>

						<h1 class="text-center"> Edit Member </h1>
						
						<div class="container">
							<form class="form-horizontal" action="?do=Update" method="POST" enctype="multipart/form-data">
								<input type="hidden" name="UserID" value="<?php echo $userid  ?>">
								<!-- Start User Name Input -->
	 							<div class="form-group form-group-lg">
									<label class="col-sm-2 control-label">Username</label>
									<div class="col-sm-10 col-md-6">
										<input type="text" value="<?php echo $row['Username'] ?>" name="Username" autocomplete="off"  class="form-control" required="required">
									</div>
								</div>
								<!-- End Username Input -->

								<!-- Start Password  Input -->
								<div class="form-group form-group-lg">
									<label class="col-sm-2 control-label">Password</label>
									<div class="col-sm-10 col-md-6">
										<input type="hidden" autocomplete="new-password" name="oldpassword" value="<?php echo($row['Password'])?>" class="form-control">

										<input type="Password" autocomplete="new-password" name="newpassword" placeholder="Leave The Field If You Not Need To Change Password" class="password form-control">
									</div>
								</div>
								<!-- End Password Input -->

								<!-- Start Email Input -->
								<div class="form-group form-group-lg">
									<label class="col-sm-2 control-label">Email</label>
									<div class="col-sm-10 col-md-6">
										<input type="email" value="<?php echo $row['Email']?>" autocomplete="off" name="Email" class="form-control" required="required">
									</div>
								</div>
								<!-- End Email Input -->

								<!-- Start Full Name Input -->
								<div class="form-group form-group-lg">
									<label class="col-sm-2 control-label">Full Name</label>
									<div class="col-sm-10 col-md-6">
										<input type="text" 
										value="<?php echo $row['FullName']?>" 
										autocomplete="off" 
										name="Full" 
										class="form-control" 
										required="required">
									</div>
								</div>
								<!-- End Full Input -->

								<!-- Start Upload Member Photo -->

								<div class="form-group form-group-lg">
									<label class="col-sm-2 control-label">User Picture</label>
									<div class="col-sm-10 col-md-6">
										<input type="file" 
											   name="img-upload" 
											   class="form-control" 
										>
									</div>
								</div>
								<!-- End Upload Member Photo -->

								<!-- Start Submit Input -->
								<div class="form-group form-group-lg">
									<div class="col-sm-offset-2 col-sm-10">
										<input type="submit" value="Save"  name="Submit" class=" btn btn-primary btn-lg">
									</div>
								</div>
								<!-- End Submit Input -->
							</form>
					</div>
				<?php 
				// Show Error IF Not Found UserID
				}else{
				echo "<div class= 'container'>";
				$msg = "<div class='alert alert-danger' >Your Account ID Not Found</div>";
				redirectHome($msg,'back',3);
				echo "</div>";


				}

		}elseif($do == 'Update'){
			echo "<h1 class='text-center'> Update Member </h1>";

			if($_SERVER['REQUEST_METHOD'] == 'POST'){

				
				// Upload File Variables

				$avatarName = $_FILES['img-upload']['name'];
				$avatarSize = $_FILES['img-upload']['size'];
				$avatarTemp = $_FILES['img-upload']['tmp_name'];
				$avatarType = $_FILES['img-upload']['type'];

				// List Of Ententions File Upload 

				$avatarAllowedExtention = array('jpeg','png','jpg','gif');

				// Get Avatar Extentions and Compare it before save it


				//trigger exception in a "try" block
		
				$avatarExtention = strtolower(end(explode('.',$_FILES['img-upload']['name'])));
				$Avatar = rand(0,10000000000000000) .'_' .$avatarName ;


				// Get Variables From Forms
				$id      = $_POST['UserID'];
				$user    = $_POST['Username'];
				$email   = $_POST['Email'];
				$name    = $_POST['Full'];

	
				$pass =(empty($_POST['newpassword'])) ? $_POST['oldpassword'] : sha1($_POST['newpassword']);
				// Validate The Form
				$FormError = array();
				if(strlen($user) < 3){
					$FormError[] = "<div class='alert alert-danger' >Username cant be less than<strong> 4 character</strong></div> ";
				}
				if(strlen($user) > 20){
					$FormError[] = " <div class='alert alert-danger' >Username cant be More than<strong> 20 character </strong></div>";
				}
				if(empty($name)){
					$FormError[] = " <div class='alert alert-danger' >Name cant be <strong>empty </strong></div>";
				}
				if(empty($email)){
					$FormError[] = " <div class='alert alert-danger'>Email cant be <strong>empty</strong> </div>";
				
				}
				if(!empty($avatarName) && ! in_array($avatarExtention, $avatarAllowedExtention)){

					$FormError[] = " This Extention <strong> Not Allowed </strong>";
				}
				if($avatarSize > 4194304) {

					$FormError[] = " This Image Cant Be More Than <strong> 4 </strong> MB";
				}
				// Loop Print Errors And Echo It
				foreach ($FormError as $Error) {
					echo "<div class='alert alert-danger'>" . $Error . "</div>";
				}
			
				// Loop Print Errors And Echo It
				foreach ($FormError as $Error) {
					echo $Error;
				}
				// Check if no error procede to continue update

				if(empty($FormError)){
					$stmt2 = $con->prepare("SELECT * From users WHERE Username = ? AND UserID !=?");
					$stmt2->execute(array($user,$id));
					$count=$stmt2->rowCount();
					
					if($count == 1){
							echo "<div class = 'container'>";
							$msg = "<div class='alert alert-danger'> Sorry That Name is Really In Users </div>";
							redirectHome($msg,'back',3);
							echo "</div>";
					}else{
						if(empty($avatarName) ){
							// Update User Data
							$stmt = $con->prepare("UPDATE users SET Username = ?,Email = ? ,FullName = ?, Password = ?  Where UserID = ?");
							$stmt->execute(array($user,$email,$name,$pass,$id));

							if ($stmt->rowCount() == 1){
									echo "<div class = 'container'>";
									$msg = "<div class='alert alert-success'>" . $stmt->rowCount()." ". "Sucess Updated </div>";

								redirectHome($msg,'back',3);
								echo "</div>";
							}else{
								echo "<div class = 'container'>";
								$msg = "<div class='alert alert-danger'>" . $stmt->rowCount()." ". "Faild Updated </div>";

								redirectHome($msg,'back',3);
								echo "</div>";
							}
						}else{
							move_uploaded_file($avatarTemp, 'Uploads\Avatars\\'.$Avatar);
							// Update User Data
							$stmt = $con->prepare("UPDATE users SET Username = ?,Email = ? ,FullName = ?, Password = ?,avatar = ? Where UserID = ?");
							$stmt->execute(array($user,$email,$name,$pass,$Avatar,$id));

							if ($stmt->rowCount() == 1){
									echo "<div class = 'container'>";
									$msg = "<div class='alert alert-success'>" . $stmt->rowCount()." ". "Sucess Updated </div>";

								redirectHome($msg,'back',3);
								echo "</div>";
							}else{
								echo "<div class = 'container'>";
								$msg = "<div class='alert alert-danger'>" . $stmt->rowCount()." ". "Faild Updated </div>";

								redirectHome($msg,'back',3);
								echo "</div>";
							}
						}


					}

					
					
					// Echo Sucess Message

				
		
				}
			}	

		}elseif($do =='Delete'){// Delete Members
                echo "<h1 class='text-center'> Add New Member </h1>";
                echo "<div class='container'>";
	            // Condition To Get UserID Successfully
	            $userid = isset($_GET['UserID']) && is_numeric($_GET['UserID']) ? intval($_GET['UserID']) : 0;
	                // Select All Data Depend To UserID
	                $stmt =$con->prepare("SELECT * From users WHERE UserID= ? LIMIT 1 "
	                                    );
	                // Execute Query
	                $stmt->execute(array($userid));
	                // Print In Array
	                $row = $stmt->fetch();
	                // Check if User Not Exist
	                $count = $stmt->rowCount();
	                // mY Condition
	                if($count > 0){ 

	                    $stmt=$con->prepare("DELETE From users WHERE UserID =:zuser");
	                    
	                    $stmt->bindParam(":zuser",$userid);

	                    $stmt->execute();

	            
	                    if ($stmt->rowCount() == 1 ){
		                    echo "<div class= 'container'>";
							$msg = "<div class= 'alert alert-success'>Record Deleted</div>";
							redirectHome($msg,'back',3);
							echo "</div>";
						}else{
							echo "<div class= 'container'>";
							$msg = "<div class= 'alert alert-danger'>Failed Record Deleted</div>";
							redirectHome($msg,'back',3);
							echo "</div>";
						}

	                }else{

					echo "<div class= 'container'>";
					$msg = "<div class= 'alert alert-danger'>Your ID Not Found </div>";
					redirectHome($msg,'back',3);
					echo "</div>";
	                }
	                echo "</div>";
	                
        }elseif($do =='Activate'){ // Activated Members
                echo "<h1 class='text-center'> Add New Member </h1>";
                echo "<div class='container'>";
	            // Condition To Get UserID Successfully
	            $userid = isset($_GET['UserID']) && is_numeric($_GET['UserID']) ? intval($_GET['UserID']) : 0;
	                // Select All Data Depend To UserID
	                $stmt =$con->prepare("SELECT * From users WHERE UserID= ? LIMIT 1 "
	                                    );
	                // Execute Query
	                $stmt->execute(array($userid));
	                // Print In Array
	                $row = $stmt->fetch();
	                // Check if User Not Exist
	                $count = $stmt->rowCount();
	                // mY Condition
	                if($count > 0){ 

	                    $stmt=$con->prepare("UPDATE users SET RegStutus = 1 WHERE UserID = ?");
	                    $stmt->execute(array($userid));
	            
	                    if ($stmt->rowCount() == 1 ){
		                    echo "<div class= 'container'>";
							$msg = "<div class= 'alert alert-success'>Record Activated</div>";
							redirectHome($msg,'back',3);
							echo "</div>";
						}else{
							echo "<div class= 'container'>";
							$msg = "<div class= 'alert alert-danger'>Failed Record Activated</div>";
							redirectHome($msg,'back',3);
							echo "</div>";
						}

	                }else{

					echo "<div class= 'container'>";
					$msg = "<div class= 'alert alert-danger'>Your ID Not Found </div>";
					redirectHome($msg,'back',3);
					echo "</div>";
	                }
	                echo "</div>";
        }else{
				echo "<div class= 'container'>";
				$msg = "<div class= 'alert alert-danger' >Sorry Cant Browse This Page Directly</div>";
				redirectHome($msg,'back',3);
				echo "</div>";
		}
		include $tpl .'footer.php';
	}else{
		header("Location: index.php");
		exit();
	}
	ob_end_flush();
?>