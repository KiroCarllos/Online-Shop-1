<?php
	// Get all Records From Any Table
	function getAllFrom($filed,$table,$where,$and=NULL,$order,$ordering='DESC'){

		global $con;

		$getAll = $con->prepare("SELECT $filed FROM $table $where $and ORDER BY $order $ordering");

		$getAll->execute();

		$All = $getAll->fetchAll();

		return $All;
	}
	/*
	// Function To Get Categories From DB [Users , Items , Comments ]

	function getCategories(){

		global $con;

		$stmt = $con->prepare("SELECT * FROM categories ORDER BY ID DESC");

		$stmt->execute();

		$rows = $stmt->fetchAll();

		return $rows;
	}

	// Function To Get Items From DB [Users , Items , Comments ]

	function getItems($where,$value,$approve = NULL){

		global $con;

		if($approve == NULL){

			$sql = 'AND Approve = 1';

		} else {
			
			$sql = NULL;
		}

		$getItem = $con->prepare("SELECT * FROM items WHERE $where = ? $sql ORDER BY item_ID DESC");

		$getItem->execute(array($value));

		$items = $getItem->fetchAll();

		return $items;
	}

	*/

	// Function To set Title Automation
	function getTitle() {

		global $pageTitle;

		if (isset($pageTitle)){

			echo $pageTitle;

		}else{
			echo 'Defult';
		}
	}

	// Add Page Redirect Function[Accept Parameter(The Message , Seconds Before Redirect)]
		function redirectHome($msg,$url = null,$seconds = 3){

			if ($url == null){

				$url = 'dashboard.php';

			}else{

				if (isset($_SERVER['HTTP_REFERER']) && $_SERVER['HTTP_REFERER'] !== '' ){

					$url = $_SERVER['HTTP_REFERER'];
				}else{

					$url = 'dashboard.php';
				}
			}
			echo  $msg;

			echo "<div class='alert alert-info'>You Will Redirect Previous Page After"." ".$seconds ."  "."Seconds </div>";

			header("refresh:$seconds;url=$url");
			exit();
	}
	// Check Username Exception To Prevent Doublecate

	function CheckItem($select,$from,$value){

		global $con;

		$stmt = $con->prepare("SELECT $select FROM $from WHERE $select = ? ");

		$stmt->execute(array($value));

		$count = $stmt->rowCount();

		return $count;

	}
	// Count Id Users To Get My Own Users
	// Get Any Count From DB
	function CountRows($item,$table,$where = null,$value = null) {

		global $con;

		if ($where == null){
			$stmt = $con->prepare("SELECT COUNT($item) FROM $table");

			$stmt->execute();

			return $stmt->fetchColumn();
		}else{ 

		$stmt = $con->prepare("SELECT COUNT($item) FROM $table WHERE $where != $value");

		$stmt->execute();

		return $stmt->fetchColumn();
		}
	}
	// Get Latest Record Function
	// Function To Get Latest Items From DB [Users , Items , Comments ]

	function getLatest($select,$table,$order,$limit=5){

		global $con;

		$stmt = $con->prepare("SELECT $select FROM $table ORDER BY $order DESC Limit $limit ");

		$stmt->execute();

		$rows = $stmt->fetchAll();

		return $rows;
	}
	// Function To Check if User Activate RegStutus

	function checkUserStutus($user){

		global $con;		
	    $stmtx =$con->prepare("SELECT 
	                            	Username, RegStutus
	                             From 
	                             	users 
	                             WHERE 
	                             	Username= ? 
	                             AND 
	                             	RegStutus = 0");
	    $stmtx->execute(array($user));

	    $stutus = $stmtx->rowCount();

	return $stutus;
		
	}