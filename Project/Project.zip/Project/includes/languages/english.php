<?php 


	function lang($phrase){

		static $lang = array (
			// Home Page
			
			// NavBar Links
			'Kiro'            =>'Kiro',
			'Home_Admin'      =>'Home',           
			'Logs'            =>'Logs',
			'Settingt'        =>'Settingt',
			'Categories'      =>'Categories',
			'Items'           =>'Items',
			'Members'         =>'Members',
			'Statices'        =>'Statices',
			'Edit Profile'    =>'Edit Profile',
			'Log Out'         =>'Log Out',
			'COMMENTS'         =>'Comments'

		// Setting
		);
		return $lang[$phrase];
	}
?>
