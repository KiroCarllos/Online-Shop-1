

	<script src=<?php echo $js ."jquery-1.12.0.min.js"?>></script>
	<script src=<?php echo $js ."bootstrap.min.js"?>></script>
	<script src=<?php echo $js ."front.js" ?>></script>
</body>
</html>